package com.example.btk_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
