class Strings {
  String welcomeText = "Welcome";
  String btk = "BTK";
  String email = "Email";
  String password = "Password";
  String login = "Login";
  String forgotPassword = "Forgot Password?";
  String or = "or";
  String signUpWith = "Sign Up With";
  String google = "Sign Up With Google";
}
